namespace SSIS.Models
{
    public enum RequisitionStatus
    {
        APPLIED,
        APPROVED,
        REJECTED,
        PROCESSING_RETRIEVAL,
        PENDING_COLLECTION,
        DELIVERED
    }
}